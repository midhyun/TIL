# TIL Project-Template

![img]

## INTRO

- 🗓 프로젝트 기간
  - 2022.10.27 ~ 2022.10.28
- 💻 사용 기술
  - Python, Django, HTML, CSS, Bootstrap5, AXIOS, JavaScript
- ⭐ 나의 역할
  - Article app CRUD 및 비동기 구현
  - 
- 💡 배운 점
  - AXIOS 와 JavaScript를 활용한 비동기 구현
  - 
  - 



## 🚩목적

> project's goal

- 영화 리뷰 게시판 구현, 비동기 및 static , media upload.
- 



# 🧾기능 소개

- 회원과 비회원(Anonymous)의 접근 차이와 

# 문제 해결

## 문제 상황





## 해결



```python

```