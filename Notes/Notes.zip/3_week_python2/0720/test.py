number = 123
cnt = 0
a = 0
while number != 0:
    number = number // 10
    cnt += 1
    print(cnt)
