lst=[]
for i in input():
    lst.append(int(i))
print(sum(lst))