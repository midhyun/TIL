# N = 10
# answer = ()
# for number in range(N + 1):
#     answer.append(number * 2)

# print(answer)

# append()는 리스트에 값을 추가하는 메서드입니다.
N = 10
answer = []
for number in range(N + 1):
    answer.append(number * 2)

print(answer)