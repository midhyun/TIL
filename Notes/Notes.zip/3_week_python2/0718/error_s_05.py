# number = 22020718
# print(len(number))

# len() 함수는 문자열, 리스트, 딕셔너리 등 iterable한 자료형의 길이를 구하는 함수입니다.

number = '22020718'
print(len(number))