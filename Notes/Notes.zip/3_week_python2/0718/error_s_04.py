# words = list(map(int, input().split()))
# print(words)
# 숫자열로 입력받았기 때문에 문자열로 바꾸어줌

words = list(map(str, input().split()))
print(words)