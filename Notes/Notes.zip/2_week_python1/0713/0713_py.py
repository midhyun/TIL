a,b,c,d,e = input().split()
print(a)