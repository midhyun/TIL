for chars in 'apple':
    if chars == 'b' :
        print('b!')
        break
else :
    print('b가 없습니다!')