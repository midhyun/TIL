# n = int(input())
# a = range(1,n+1)
# print(sum(a))

num = 0
result = 0
n = int(input())
while num < n :
    num += 1
    result += num
print(result)