numbers = [-10, -100, -30]
a = numbers[0]
for i in numbers :
    if a >= i :
        a = i
print(a)