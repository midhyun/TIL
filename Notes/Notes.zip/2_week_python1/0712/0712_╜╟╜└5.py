numbers = [3, 10, 20]
long = 0
num = 0

while numbers :
    numbers.pop(0)
    long += 1

numbers = [3, 10, 20]

for i in numbers :
    num += i
else :
    print(int(num/long))