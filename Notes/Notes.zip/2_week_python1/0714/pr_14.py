word = 'apple'
cnt = 0
for i in word:
    if i == 'a':
        cnt += 1
print(cnt)